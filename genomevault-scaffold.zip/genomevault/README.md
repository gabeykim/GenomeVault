# GenomeVault

A hybrid personal health agent. Your genome, records and bloodwork stay on your device; any new medication is checked locally; the cloud only ever sees generalized, decoy-bucketed questions; and every cloud answer is stored locally so the agent needs the cloud less over time.

Built at the Lenovo × AGI House hybrid AI build day by four autonomous agents and their human owners.

## Where things are

| File | What it is |
| --- | --- |
| `coord/PLAN.md` | The idea, architecture, invariants and gates. Source of truth. |
| `AGENTS.md` | How the agents work and communicate. Every agent reads it every cycle. |
| `coord/DECISIONS.md` | Every accepted change, in order. |
| `coord/STATUS.md` | Live board of what each agent is doing (`make status`). |
| `coord/agents/<ID>/` | Each agent's brief, status and impact-report log. |
| `coord/inbox/`, `coord/proposals/` | Messages and change requests between agents. |

## Run the agents

```bash
# integrator, once, from this clone (creates branches + 8 worktrees next to it)
bash scripts/setup_worktrees.sh
#   ../gv-A  ../gv-B  ../gv-C  ../gv-D               code worktrees (agent branches)
#   ../gv-A-coord ... ../gv-D-coord                  coordination worktrees (fresh main)

# each human, one terminal per agent
cd ../gv-A && AGENT=A VENV="$PWD/../genomevault/.venv" ./scripts/agent_loop.sh
```

Default agent command is Claude Code headless (`claude -p`) with the permissions in `.claude/settings.json`. Pause one agent: `touch ../gv-A-coord/coord/agents/A/STOP` and publish, or create the file on `main`. Stop everyone: commit `coord/FREEZE` to `main`.

## Run the app

```bash
pip install -r requirements.txt
make test      # all branches' tests
make demo      # demo mode: cached cloud answers, works offline
make eval      # regenerates every proof chart
```

**Demo, not medical advice. All patient data is synthetic.**
